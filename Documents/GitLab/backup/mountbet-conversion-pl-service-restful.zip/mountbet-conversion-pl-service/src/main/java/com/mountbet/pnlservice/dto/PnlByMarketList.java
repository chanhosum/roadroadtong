package com.mountbet.pnlservice.dto;

import java.util.List;

public class PnlByMarketList {
    public List<PnlByMarketInsert> pnlByMarketList;

    public List<PnlByMarketInsert> getPnlByMarketList() {
        return pnlByMarketList;
    }

    public void setPnlByMarketList(List<PnlByMarketInsert> pnlByMarketList) {
        this.pnlByMarketList = pnlByMarketList;
    }

    @Override
    public String toString() {
        return "PnlByMarketList{" +
                "pnlByMarketList=" + pnlByMarketList +
                '}';
    }
}
