package com.mountbet.pnlservice.repository;


import com.mountbet.pnlservice.entity.BetfairByMarket;
import com.mountbet.pnlservice.entity.key.BetfairByMarketKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface BetfairByMarketRepository extends CassandraRepository<BetfairByMarket, BetfairByMarketKey> {
}
