package com.mountbet.pnlservice.service;


import com.datastax.driver.core.utils.UUIDs;
import com.mountbet.pnlservice.dto.BetfairByMarketInsert;
import com.mountbet.pnlservice.dto.BetfairByMarketList;
import com.mountbet.pnlservice.entity.BetfairByMarket;
import com.mountbet.pnlservice.entity.key.BetfairByMarketKey;
import com.mountbet.pnlservice.repository.BetfairByMarketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class BetfairByMarketService {
    private static final Logger LOG = LoggerFactory.getLogger(BetfairByMarketService.class);

    @Autowired
    private BetfairByMarketRepository betfairByMarketRepository;

    public void restful(BetfairByMarketList betfairByMarketList){
        for(BetfairByMarketInsert betfairByMarket: betfairByMarketList.getBetfairByMarketList()){
            BetfairByMarket betfairByMarketNew = new BetfairByMarket();

            BetfairByMarketKey betfairByMarketKeyNew = new BetfairByMarketKey();
            betfairByMarketKeyNew.setAccountId(betfairByMarket.getAccountId());
            betfairByMarketKeyNew.setBettorId(betfairByMarket.getBettorId());
            betfairByMarketKeyNew.setId(UUIDs.timeBased());
            betfairByMarketKeyNew.setMarketId(betfairByMarket.getMarketId());
            betfairByMarketNew.setKey(betfairByMarketKeyNew);

            betfairByMarketNew.setBackSubtotal(betfairByMarket.getBackSubtotal());
            betfairByMarketNew.setCommission(betfairByMarket.getCommission());
            betfairByMarketNew.setLaySubtotal(betfairByMarket.getLaySubtotal());
            betfairByMarketNew.setMarketDetailsId(betfairByMarket.getMarketDetailsId());
            betfairByMarketNew.setMarketSettledDate(betfairByMarket.getMarketSettledDate());
            betfairByMarketNew.setMarketSubtotal(betfairByMarket.getMarketSubtotal());
            betfairByMarketNew.setNetMarketTotal(betfairByMarket.getNetMarketTotal());
            betfairByMarketNew.setOriginalId(betfairByMarket.getOriginalId());
            betfairByMarketNew.setSportId(betfairByMarket.getSportId());

            betfairByMarketRepository.insert(betfairByMarketNew);
        }
    }
}
