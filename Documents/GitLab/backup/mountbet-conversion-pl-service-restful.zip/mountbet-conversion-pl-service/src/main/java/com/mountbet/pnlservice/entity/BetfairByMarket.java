package com.mountbet.pnlservice.entity;


import com.datastax.driver.core.DataType;
import com.mountbet.pnlservice.entity.key.BetfairByMarketKey;
import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.math.BigDecimal;
import java.util.Date;

@Table(value = "betfair_by_market")
public class BetfairByMarket {
    @PrimaryKey
    private BetfairByMarketKey key;

    @Column(value = "back_subtotal")
    @CassandraType(type = DataType.Name.DECIMAL)
    private BigDecimal backSubtotal;

    @Column(value = "commission")
    @CassandraType(type = DataType.Name.DECIMAL)
    private BigDecimal commission;

    @Column(value = "lay_subtotal")
    @CassandraType(type = DataType.Name.DECIMAL)
    private BigDecimal laySubtotal;

    @Column(value = "market_details_id")
    @CassandraType(type = DataType.Name.BIGINT)
    private Long marketDetailsId;

    @Column(value = "market_settled_date")
    @CassandraType(type = DataType.Name.TIMESTAMP)
    private Date marketSettledDate;

    @Column(value = "market_subtotal")
    @CassandraType(type = DataType.Name.DECIMAL)
    private BigDecimal marketSubtotal;

    @Column(value = "net_market_total")
    @CassandraType(type = DataType.Name.DECIMAL)
    private BigDecimal netMarketTotal;

    @Column(value = "original_id")
    @CassandraType(type = DataType.Name.BIGINT)
    private Long originalId;

    @Column(value = "sport_id")
    @CassandraType(type = DataType.Name.BIGINT)
    private Long sportId;

    public BetfairByMarketKey getKey() {
        return key;
    }

    public void setKey(BetfairByMarketKey key) {
        this.key = key;
    }

    public BigDecimal getBackSubtotal() {
        return backSubtotal;
    }

    public void setBackSubtotal(BigDecimal backSubtotal) {
        this.backSubtotal = backSubtotal;
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public BigDecimal getLaySubtotal() {
        return laySubtotal;
    }

    public void setLaySubtotal(BigDecimal laySubtotal) {
        this.laySubtotal = laySubtotal;
    }

    public Long getMarketDetailsId() {
        return marketDetailsId;
    }

    public void setMarketDetailsId(Long marketDetailsId) {
        this.marketDetailsId = marketDetailsId;
    }

    public Date getMarketSettledDate() {
        return marketSettledDate;
    }

    public void setMarketSettledDate(Date marketSettledDate) {
        this.marketSettledDate = marketSettledDate;
    }

    public BigDecimal getMarketSubtotal() {
        return marketSubtotal;
    }

    public void setMarketSubtotal(BigDecimal marketSubtotal) {
        this.marketSubtotal = marketSubtotal;
    }

    public BigDecimal getNetMarketTotal() {
        return netMarketTotal;
    }

    public void setNetMarketTotal(BigDecimal netMarketTotal) {
        this.netMarketTotal = netMarketTotal;
    }

    public Long getOriginalId() {
        return originalId;
    }

    public void setOriginalId(Long originalId) {
        this.originalId = originalId;
    }

    public Long getSportId() {
        return sportId;
    }

    public void setSportId(Long sportId) {
        this.sportId = sportId;
    }

    @Override
    public String toString() {
        return "BetfairByMarket{" +
                "key=" + key +
                ", backSubtotal=" + backSubtotal +
                ", commission=" + commission +
                ", laySubtotal=" + laySubtotal +
                ", marketDetailsId=" + marketDetailsId +
                ", marketSettledDate=" + marketSettledDate +
                ", marketSubtotal=" + marketSubtotal +
                ", netMarketTotal=" + netMarketTotal +
                ", originalId=" + originalId +
                ", sportId=" + sportId +
                '}';
    }
}
