package com.mountbet.pnlservice.controller;

import com.mountbet.pnlservice.dto.PnlByMarketList;
import com.mountbet.pnlservice.service.PnlByMarketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RequestMapping(path = "/pnl")
@RestController
public class PnlByMarketController {
    private static final Logger LOG = LoggerFactory.getLogger(BetfairByMarketController.class);

    @Autowired
    private PnlByMarketService pnlByMarketService;

    @PostMapping(path = "/restful", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public void restful(@RequestHeader HttpHeaders httpHeaders, @RequestBody PnlByMarketList pnlByMarketList) {
        LOG.debug("/restful");
        LOG.debug(pnlByMarketList.toString());
        pnlByMarketService.restful(pnlByMarketList);
    }

}