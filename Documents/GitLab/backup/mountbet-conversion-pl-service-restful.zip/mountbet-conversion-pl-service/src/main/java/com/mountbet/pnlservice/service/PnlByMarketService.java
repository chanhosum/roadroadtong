package com.mountbet.pnlservice.service;

import com.datastax.driver.core.utils.UUIDs;
import com.mountbet.pnlservice.dto.PnlByMarketInsert;
import com.mountbet.pnlservice.dto.PnlByMarketList;
import com.mountbet.pnlservice.entity.PnlByMarket;
import com.mountbet.pnlservice.entity.key.PnlByMarketKey;
import com.mountbet.pnlservice.repository.PnlByMarketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PnlByMarketService {
    private static final Logger LOG = LoggerFactory.getLogger(PnlByMarketService.class);

    @Autowired
    private PnlByMarketRepository pnlByMarketRepository;

    public void restful(PnlByMarketList pnlByMarketList){
        for(PnlByMarketInsert pnlByMarket: pnlByMarketList.getPnlByMarketList()){
            PnlByMarket pnlByMarketNew = new PnlByMarket();

            PnlByMarketKey pnlByMarketKeyNew = new PnlByMarketKey();
            pnlByMarketKeyNew.setAccountId(pnlByMarket.getAccountId());
            pnlByMarketKeyNew.setBettorId(pnlByMarket.getBettorId());
            pnlByMarketKeyNew.setId(UUIDs.timeBased());
            pnlByMarketKeyNew.setMarketId(pnlByMarket.getMarketId());
            pnlByMarketNew.setKey(pnlByMarketKeyNew);

            pnlByMarketNew.setBackSubtotal(pnlByMarket.getBackSubtotal());
            pnlByMarketNew.setCommission(pnlByMarket.getCommission());
            pnlByMarketNew.setLaySubtotal(pnlByMarket.getLaySubtotal());
            pnlByMarketNew.setMarketDetailsId(pnlByMarket.getMarketDetailsId());
            pnlByMarketNew.setMarketSettledDate(pnlByMarket.getMarketSettledDate());
            pnlByMarketNew.setMarketSubtotal(pnlByMarket.getMarketSubtotal());
            pnlByMarketNew.setNetMarketTotal(pnlByMarket.getNetMarketTotal());
            pnlByMarketNew.setOriginalId(pnlByMarket.getOriginalId());
            pnlByMarketNew.setSportId(pnlByMarket.getSportId());

            pnlByMarketRepository.insert(pnlByMarketNew);
        }
    }
}
