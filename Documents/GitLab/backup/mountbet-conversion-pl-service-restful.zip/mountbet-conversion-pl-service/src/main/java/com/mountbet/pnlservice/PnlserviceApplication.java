package com.mountbet.pnlservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PnlserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PnlserviceApplication.class, args);
    }
}
