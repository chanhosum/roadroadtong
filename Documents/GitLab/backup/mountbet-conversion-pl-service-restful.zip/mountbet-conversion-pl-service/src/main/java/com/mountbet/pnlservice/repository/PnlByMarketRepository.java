package com.mountbet.pnlservice.repository;

import com.mountbet.pnlservice.entity.PnlByMarket;
import com.mountbet.pnlservice.entity.key.PnlByMarketKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface PnlByMarketRepository extends CassandraRepository<PnlByMarket, PnlByMarketKey> {
}
