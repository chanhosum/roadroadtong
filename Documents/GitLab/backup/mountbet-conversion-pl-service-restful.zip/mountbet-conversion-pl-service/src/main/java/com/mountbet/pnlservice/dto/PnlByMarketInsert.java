package com.mountbet.pnlservice.dto;

import java.math.BigDecimal;
import java.util.Date;

public class PnlByMarketInsert {
    private String marketId;

    private Long bettorId;

    private Long accountId;

    private BigDecimal backSubtotal;

    private BigDecimal commission;

    private BigDecimal laySubtotal;

    private Long marketDetailsId;

    private Date marketSettledDate;

    private BigDecimal marketSubtotal;

    private BigDecimal netMarketTotal;

    private Long originalId;

    private Long sportId;

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public Long getBettorId() {
        return bettorId;
    }

    public void setBettorId(Long bettorId) {
        this.bettorId = bettorId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getBackSubtotal() {
        return backSubtotal;
    }

    public void setBackSubtotal(BigDecimal backSubtotal) {
        this.backSubtotal = backSubtotal;
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public BigDecimal getLaySubtotal() {
        return laySubtotal;
    }

    public void setLaySubtotal(BigDecimal laySubtotal) {
        this.laySubtotal = laySubtotal;
    }

    public Long getMarketDetailsId() {
        return marketDetailsId;
    }

    public void setMarketDetailsId(Long marketDetailsId) {
        this.marketDetailsId = marketDetailsId;
    }

    public Date getMarketSettledDate() {
        return marketSettledDate;
    }

    public void setMarketSettledDate(Date marketSettledDate) {
        this.marketSettledDate = marketSettledDate;
    }

    public BigDecimal getMarketSubtotal() {
        return marketSubtotal;
    }

    public void setMarketSubtotal(BigDecimal marketSubtotal) {
        this.marketSubtotal = marketSubtotal;
    }

    public BigDecimal getNetMarketTotal() {
        return netMarketTotal;
    }

    public void setNetMarketTotal(BigDecimal netMarketTotal) {
        this.netMarketTotal = netMarketTotal;
    }

    public Long getOriginalId() {
        return originalId;
    }

    public void setOriginalId(Long originalId) {
        this.originalId = originalId;
    }

    public Long getSportId() {
        return sportId;
    }

    public void setSportId(Long sportId) {
        this.sportId = sportId;
    }

    @Override
    public String toString() {
        return "PnlByMarketInsert{" +
                "marketId='" + marketId + '\'' +
                ", bettorId=" + bettorId +
                ", accountId=" + accountId +
                ", backSubtotal=" + backSubtotal +
                ", commission=" + commission +
                ", laySubtotal=" + laySubtotal +
                ", marketDetailsId=" + marketDetailsId +
                ", marketSettledDate=" + marketSettledDate +
                ", marketSubtotal=" + marketSubtotal +
                ", netMarketTotal=" + netMarketTotal +
                ", originalId=" + originalId +
                ", sportId=" + sportId +
                '}';
    }
}
