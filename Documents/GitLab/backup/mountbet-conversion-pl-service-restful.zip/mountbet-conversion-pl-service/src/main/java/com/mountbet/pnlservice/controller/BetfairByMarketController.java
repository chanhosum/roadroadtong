package com.mountbet.pnlservice.controller;


import com.mountbet.pnlservice.dto.BetfairByMarketList;
import com.mountbet.pnlservice.service.BetfairByMarketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RequestMapping(path = "/market")
@RestController
public class BetfairByMarketController {
    private static final Logger LOG = LoggerFactory.getLogger(BetfairByMarketController.class);

    @Autowired
    private BetfairByMarketService betfairByMarketService;

    @PostMapping(path = "/restful", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public void restful(@RequestHeader HttpHeaders httpHeaders, @RequestBody BetfairByMarketList betfairByMarketList) {
        LOG.debug("/restful");
        LOG.debug(betfairByMarketList.toString());
        betfairByMarketService.restful(betfairByMarketList);
    }

}