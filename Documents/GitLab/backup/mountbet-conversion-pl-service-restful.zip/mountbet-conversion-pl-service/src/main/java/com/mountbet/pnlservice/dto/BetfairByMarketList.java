package com.mountbet.pnlservice.dto;

import java.util.List;

public class BetfairByMarketList {
    public List<BetfairByMarketInsert> betfairByMarketList;

    public List<BetfairByMarketInsert> getBetfairByMarketList() {
        return betfairByMarketList;
    }

    public void setBetfairByMarketList(List<BetfairByMarketInsert> betfairByMarketList) {
        this.betfairByMarketList = betfairByMarketList;
    }

    @Override
    public String toString() {
        return "BetfairByMarketList{" +
                "betfairByMarketList=" + betfairByMarketList +
                '}';
    }
}
